# Jarvis (Android assistant)

English-only voice assistant. Deepgram (listening) + Groq (answers) + Groq Orpheus (voice).

## Keys (2 total)
- Groq API key: console.groq.com (used for answers AND voice)
- Deepgram API key: deepgram.com

## Build the APK with GitHub Actions
1. Push this whole folder (including the hidden .github folder) to a GitHub repo.
2. Actions tab > "Build Jarvis APK" > Run workflow (it also runs on every push).
3. Download the `jarvis-debug-apk` artifact, unzip, install app-debug.apk on your phone.

## First run
Open Jarvis, paste both keys, Save, tap "Test voice". Then do setup steps 1-3 in the app.
Invoke with the assistant gesture (long-press home/power, depending on your phone).

## Not verified
Written without compiling or testing on a device. If the build fails, send the Actions error log.
If voice returns an HTTP 400/403, open the Orpheus model page in the Groq console and accept its terms (unconfirmed).
