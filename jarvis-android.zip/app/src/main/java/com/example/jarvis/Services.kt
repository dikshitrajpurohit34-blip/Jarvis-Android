package com.example.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.util.Log
import android.view.View
import android.widget.TextView

class JarvisVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.i("JARVIS", "VoiceInteractionService ready")
    }
}

class JarvisSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

/** Stub only: lets Android list Jarvis as an assistant. STT is cloud-only (Deepgram). */
class JarvisStubRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, listener: Callback?) {
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }
    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}

class JarvisSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    private var tasks: TaskManager? = null
    private var statusView: TextView? = null
    private val main = Handler(Looper.getMainLooper())

    // When we hide the overlay ourselves (to act on another app) the task must keep running.
    @Volatile private var keepTaskOnHide = false

    override fun onCreateContentView(): View {
        val v = layoutInflater.inflate(R.layout.session_listening, null)
        statusView = v.findViewById(R.id.status_text)
        return v
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        keepTaskOnHide = false
        tasks?.cancel()
        tasks = TaskManager(ctx.applicationContext, this).also { it.start() }
    }

    override fun onHide() {
        if (keepTaskOnHide) keepTaskOnHide = false else tasks?.cancel()
        super.onHide()
    }

    fun setStatus(text: String) {
        statusView?.post { statusView?.text = text }
    }

    fun hideSession(keepTask: Boolean = false) {
        main.post {
            keepTaskOnHide = keepTask
            hide()
        }
    }

    /** Launch another app's activity from the assistant session. */
    fun launch(intent: Intent) {
        keepTaskOnHide = true
        main.post {
            try {
                startAssistantActivity(intent)
            } catch (e: Exception) {
                Log.w("JARVIS", "startAssistantActivity failed, falling back", e)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(intent) } catch (e2: Exception) { Log.e("JARVIS", "launch failed", e2) }
            }
        }
    }
}
