package com.example.jarvis

sealed class Action {
    data class LaunchApp(val app: String) : Action()
    data class SearchInApp(val app: String, val query: String) : Action()
    data class SearchWeb(val query: String) : Action()
    data class OpenSettings(val page: String) : Action()
    data class Global(val type: GlobalType) : Action()
    data class Scroll(val forward: Boolean) : Action()
    data class ClickText(val text: String) : Action()
    data class EnterText(val text: String) : Action()
    data class Ask(val question: String) : Action()
    object Cancel : Action()
}

enum class GlobalType { BACK, HOME, RECENTS }

/** Pure function: no network, no Android calls. Most specific patterns first. */
object CommandInterpreter {
    private val openAndSearch = Regex("""^(?:open|launch|start)\s+(.+?)\s+and\s+search(?:\s+for)?\s+(.+)$""")
    private val settingsPage = Regex("""^(?:open\s+)?(wi-?fi|bluetooth|display|sound|battery|location)\s+settings$""")
    private val openApp = Regex("""^(?:open|launch|start)\s+(.+)$""")
    private val searchWeb = Regex("""^(?:search|google)(?:\s+for)?\s+(.+)$""")
    private val click = Regex("""^click(?:\s+on)?(?:\s+the)?\s+(.+)$""")
    private val enter = Regex("""^(?:enter|type)\s+(.+)$""")

    fun interpret(raw: String): Action {
        val t = raw.trim().lowercase().trimEnd('.', '?', '!')
        openAndSearch.find(t)?.let { return Action.SearchInApp(it.groupValues[1], it.groupValues[2]) }
        settingsPage.find(t)?.let { return Action.OpenSettings(it.groupValues[1]) }
        openApp.find(t)?.let { return Action.LaunchApp(it.groupValues[1]) }
        searchWeb.find(t)?.let { return Action.SearchWeb(it.groupValues[1]) }
        return when {
            t in setOf("go back", "back") -> Action.Global(GlobalType.BACK)
            t in setOf("go home", "home") -> Action.Global(GlobalType.HOME)
            t in setOf("recents", "show recent apps") -> Action.Global(GlobalType.RECENTS)
            t.startsWith("scroll down") -> Action.Scroll(forward = true)
            t.startsWith("scroll up") -> Action.Scroll(forward = false)
            t in setOf("cancel", "never mind", "nevermind", "stop") -> Action.Cancel
            click.matches(t) -> Action.ClickText(click.find(t)!!.groupValues[1])
            enter.matches(t) -> Action.EnterText(enter.find(t)!!.groupValues[1])
            else -> Action.Ask(raw.trim())
        }
    }
}
