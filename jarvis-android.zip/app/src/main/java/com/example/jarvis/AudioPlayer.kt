package com.example.jarvis

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

class AudioPlayer(private val ctx: Context) {
    private var player: MediaPlayer? = null

    /** Suspends until playback finishes; cancelling the coroutine stops audio. */
    suspend fun play(wav: ByteArray) = suspendCancellableCoroutine<Unit> { cont ->
        val file = File.createTempFile("tts", ".wav", ctx.cacheDir).apply { writeBytes(wav) }
        val mp = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            setDataSource(file.path)
            setOnCompletionListener { release(); file.delete(); if (cont.isActive) cont.resume(Unit) }
            setOnErrorListener { _, _, _ -> release(); file.delete(); if (cont.isActive) cont.resume(Unit); true }
            prepare(); start()
        }
        player = mp
        cont.invokeOnCancellation {
            try { mp.stop() } catch (_: Exception) {}
            mp.release(); file.delete()
        }
    }

    fun stop() {
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
    }
}
