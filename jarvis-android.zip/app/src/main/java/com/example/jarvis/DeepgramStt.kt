package com.example.jarvis

import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONObject
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class NoSpeechException : Exception("No speech detected")
class ApiKeyException(val service: String) : Exception("$service key rejected")

class DeepgramStt(
    private val client: OkHttpClient,
    private val apiKey: String,
    private val language: String = "en",   // English only. "en-IN" may suit an Indian accent; verify support.
) {
    suspend fun listenOnce(): String = suspendCancellableCoroutine { cont ->
        val capture = AudioCapture()
        val finals = StringBuilder()
        var socket: WebSocket? = null

        fun finish(result: Result<String>) {
            capture.stop()
            socket?.send("""{"type":"CloseStream"}""")
            socket?.close(1000, null)
            if (cont.isActive) {
                result.fold({ cont.resume(it) }, { cont.resumeWithException(it) })
            }
        }

        val url = "wss://api.deepgram.com/v1/listen" +
            "?model=nova-3&language=$language&encoding=linear16&sample_rate=16000&channels=1" +
            "&interim_results=true&endpointing=500&smart_format=true"
        val request = Request.Builder().url(url).addHeader("Authorization", "Token $apiKey").build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                try {
                    capture.start { frame -> ws.send(ByteString.of(*frame)) }
                } catch (e: Exception) { finish(Result.failure(e)) }
            }

            override fun onMessage(ws: WebSocket, text: String) {
                val json = JSONObject(text)
                if (json.optString("type") != "Results") return   // ignore Metadata / UtteranceEnd
                val alt = json.getJSONObject("channel").getJSONArray("alternatives").getJSONObject(0)
                val t = alt.optString("transcript")
                if (json.optBoolean("is_final") && t.isNotBlank()) finals.append(t).append(' ')
                if (json.optBoolean("speech_final")) {
                    val out = finals.toString().trim()
                    finish(if (out.isEmpty()) Result.failure(NoSpeechException()) else Result.success(out))
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                if (response?.code == 401) finish(Result.failure(ApiKeyException("Deepgram")))
                else finish(Result.failure(t))
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                val out = finals.toString().trim()
                finish(if (out.isEmpty()) Result.failure(NoSpeechException()) else Result.success(out))
            }
        })

        cont.invokeOnCancellation { capture.stop(); socket?.cancel() }
    }
}
