package com.example.jarvis

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import java.io.IOException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/** One coroutine job per invocation. Everything that can fail ends in a spoken (or on-screen) sentence. */
class TaskManager(private val ctx: Context, private val session: JarvisSession) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    private val settings = SettingsManager(ctx)
    private val player = AudioPlayer(ctx)

    fun start() {
        job = scope.launch {
            var reply: String? = null
            try {
                if (settings.groqKey().isBlank() || settings.deepgramKey().isBlank()) {
                    reply = "Please add your keys in the Jarvis app."
                } else {
                    session.setStatus("Listening...")
                    val transcript = withTimeout(20_000) {
                        DeepgramStt(http, settings.deepgramKey()).listenOnce()
                    }
                    Log.i("JARVIS", "Heard: $transcript")
                    session.setStatus("Thinking...")
                    val action = CommandInterpreter.interpret(transcript)
                    reply = ActionExecutor(ctx, session, http, settings).execute(action)
                }
            } catch (e: TimeoutCancellationException) {
                reply = "I didn't hear anything."
            } catch (e: CancellationException) {
                throw e
            } catch (e: NoSpeechException) {
                reply = "I didn't catch that."
            } catch (e: ApiKeyException) {
                reply = "Please check your ${e.service} key in the Jarvis app."
            } catch (e: UnknownHostException) {
                reply = "I can't reach the internet."
            } catch (e: IOException) {
                Log.e("JARVIS", "Network failure", e)
                reply = "I'm having network trouble."
            } catch (e: Exception) {
                Log.e("JARVIS", "Pipeline failed", e)
                reply = "Sorry, something went wrong."
            }
            if (!reply.isNullOrBlank()) speak(reply)
            session.hideSession()
        }
    }

    private suspend fun speak(text: String) {
        session.setStatus(text)          // always visible, even if TTS fails
        try {
            coroutineScope {
                val chunks = TtsText.split(text)
                if (chunks.isEmpty()) return@coroutineScope
                val tts = GroqTts(http, settings)
                var pending = async(Dispatchers.IO) { tts.synthesize(chunks[0]) }
                for (i in chunks.indices) {
                    val audio = pending.await()
                    if (i + 1 < chunks.size) pending = async(Dispatchers.IO) { tts.synthesize(chunks[i + 1]) }
                    withContext(Dispatchers.Main) { player.play(audio) }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("JARVIS", "TTS failed", e)
        }
    }

    fun cancel() {
        job?.cancel()
        player.stop()
        scope.coroutineContext.cancelChildren()
    }
}
