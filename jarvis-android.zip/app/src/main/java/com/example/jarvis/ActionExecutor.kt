package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient

/** Returns the sentence to speak (or null for none). Network work runs on Dispatchers.IO. */
class ActionExecutor(
    private val ctx: Context,
    private val session: JarvisSession,
    private val http: OkHttpClient,
    private val settings: SettingsManager,
) {
    private val aliases = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "settings" to "com.android.settings",
    )

    suspend fun execute(a: Action): String? = when (a) {
        is Action.LaunchApp -> launchApp(a.app)
        is Action.SearchInApp -> {
            val q = Uri.encode(a.query)
            val url = if (a.app == "youtube") "https://www.youtube.com/results?search_query=$q"
                      else "https://www.google.com/search?q=$q"
            view(url)
            "Searching for ${a.query}."
        }
        is Action.SearchWeb -> {
            view("https://www.google.com/search?q=${Uri.encode(a.query)}")
            "Searching for ${a.query}."
        }
        is Action.OpenSettings -> openSettings(a.page)
        is Action.Global -> viaAccessibility { s ->
            s.performGlobalAction(
                when (a.type) {
                    GlobalType.BACK -> AccessibilityService.GLOBAL_ACTION_BACK
                    GlobalType.HOME -> AccessibilityService.GLOBAL_ACTION_HOME
                    GlobalType.RECENTS -> AccessibilityService.GLOBAL_ACTION_RECENTS
                }
            )
        }
        is Action.Scroll -> viaAccessibility { it.scroll(a.forward) }
        is Action.ClickText -> viaAccessibility { it.clickByText(a.text) }
        is Action.EnterText -> viaAccessibility { it.enterText(a.text) }
        is Action.Ask -> withContext(Dispatchers.IO) { GroqClient(http, settings).ask(a.question) }
        Action.Cancel -> null
    }

    private fun view(url: String) = session.launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun launchApp(name: String): String {
        val intent = resolveLaunchIntent(name) ?: return "I couldn't find an app called $name."
        session.launch(intent)
        return "Opening $name."
    }

    private fun resolveLaunchIntent(name: String): Intent? {
        val pm = ctx.packageManager
        aliases[name]?.let { pkg -> pm.getLaunchIntentForPackage(pkg)?.let { return it } }
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase() == name
        } ?: return null
        return pm.getLaunchIntentForPackage(match.activityInfo.packageName)
    }

    private fun openSettings(page: String): String {
        val action = when (page.replace("-", "")) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        session.launch(Intent(action))
        return "Opening $page settings."
    }

    /** Hide the overlay first so rootInActiveWindow is the target app, then act. */
    private suspend fun viaAccessibility(block: (JarvisAccessibilityService) -> Boolean): String {
        val svc = JarvisAccessibilityService.instance
            ?: return "Please enable the Jarvis accessibility service in settings."
        session.hideSession(keepTask = true)
        delay(400)
        return if (block(svc)) "Done." else "I couldn't do that on this screen."
    }
}
