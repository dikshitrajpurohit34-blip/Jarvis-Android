package com.example.jarvis

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SettingsManager(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "jarvis_prefs",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun groqKey() = prefs.getString("groq_key", "") ?: ""
    fun deepgramKey() = prefs.getString("deepgram_key", "") ?: ""
    fun groqModel() = prefs.getString("groq_model", DEFAULT_MODEL) ?: DEFAULT_MODEL
    fun ttsVoice() = prefs.getString("tts_voice", "autumn") ?: "autumn"
    fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()

    companion object {
        const val DEFAULT_MODEL = "llama-3.3-70b-versatile"   // configurable; verify it is still offered
        val VOICES = listOf("autumn", "diana", "hannah", "austin", "daniel", "troy")
    }
}
