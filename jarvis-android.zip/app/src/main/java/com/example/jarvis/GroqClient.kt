package com.example.jarvis

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GroqClient(private val client: OkHttpClient, private val settings: SettingsManager) {
    private val system = "You are Jarvis, a voice assistant on an Android phone. " +
        "Answer in one to three short plain English sentences. No markdown, lists or symbols; " +
        "your reply will be read aloud."

    /** Blocking; call from Dispatchers.IO. Always returns a sentence suitable for speech. */
    fun ask(question: String): String {
        val model = settings.groqModel()
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.5)
            .put("max_completion_tokens", 512)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", question)))
        if (model.contains("gpt-oss")) body.put("reasoning_effort", "low")
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .addHeader("Authorization", "Bearer ${settings.groqKey()}")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { resp ->
            return when {
                resp.code == 401 -> "My Groq key looks invalid."
                resp.code == 429 -> "I'm being rate limited. Try again in a moment."
                !resp.isSuccessful -> "The AI service returned an error."
                else -> JSONObject(resp.body!!.string())
                    .getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").optString("content").trim()
                    .ifEmpty { "I don't have an answer for that." }
            }
        }
    }
}
