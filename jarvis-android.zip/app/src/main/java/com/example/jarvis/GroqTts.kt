package com.example.jarvis

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

/** Groq Orpheus (English) text-to-speech. Returns WAV bytes. Uses the same Groq key as the LLM. */
class GroqTts(private val client: OkHttpClient, private val settings: SettingsManager) {
    suspend fun synthesize(text: String): ByteArray = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", "canopylabs/orpheus-v1-english")
            .put("voice", settings.ttsVoice())
            .put("input", text)
            .put("response_format", "wav")
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/speech")
            .addHeader("Authorization", "Bearer ${settings.groqKey()}")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(req).execute().use { r ->
            if (r.code == 401) throw ApiKeyException("Groq")
            if (!r.isSuccessful) error("TTS HTTP ${r.code}: ${r.body?.string()?.take(300)}")
            r.body!!.bytes()
        }
    }
}

/** Orpheus input is short per request, so speak in sentence-sized chunks (limit not verified; kept conservative). */
object TtsText {
    private const val MAX = 190

    fun clean(s: String) = s.replace(Regex("[\\[\\]*#`_~]"), "").replace(Regex("\\s+"), " ").trim()

    fun split(text: String): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        for (sentence in clean(text).split(Regex("(?<=[.!?])\\s+"))) {
            var rest = sentence
            while (rest.length > MAX) {
                val cut = rest.lastIndexOf(' ', MAX).takeIf { it > 0 } ?: MAX
                if (cur.isNotEmpty()) { out.add(cur.toString()); cur.clear() }
                out.add(rest.substring(0, cut).trim())
                rest = rest.substring(cut).trim()
            }
            if (rest.isEmpty()) continue
            if (cur.isNotEmpty() && cur.length + 1 + rest.length > MAX) { out.add(cur.toString()); cur.clear() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(rest)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out.filter { it.isNotBlank() }
    }
}
