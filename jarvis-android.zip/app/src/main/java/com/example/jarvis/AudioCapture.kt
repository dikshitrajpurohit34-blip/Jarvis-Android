package com.example.jarvis

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.concurrent.thread

class AudioCapture {
    private var recorder: AudioRecord? = null
    @Volatile private var running = false

    @SuppressLint("MissingPermission") // RECORD_AUDIO is requested in MainActivity
    fun start(onFrame: (ByteArray) -> Unit) {
        val rate = 16_000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val frameBytes = maxOf(min, 3_200)            // ~100 ms of 16 kHz mono PCM16
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, frameBytes * 2
        )
        check(rec.state == AudioRecord.STATE_INITIALIZED) { "Mic unavailable (permission?)" }
        recorder = rec
        running = true
        rec.startRecording()
        thread(name = "jarvis-audio") {
            val buf = ByteArray(frameBytes)
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onFrame(buf.copyOf(n)) else if (n < 0) break
            }
        }
    }

    fun stop() {
        running = false
        try { recorder?.stop() } catch (_: IllegalStateException) {}
        recorder?.release()
        recorder = null
    }
}
