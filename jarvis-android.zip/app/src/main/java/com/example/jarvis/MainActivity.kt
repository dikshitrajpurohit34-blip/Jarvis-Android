package com.example.jarvis

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient

class MainActivity : AppCompatActivity() {
    private lateinit var settings: SettingsManager
    private lateinit var status: TextView
    private val scope = MainScope()
    private val http = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = SettingsManager(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, pad, 0, 0) }
        fun secret(hint: String) = EditText(this).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }
        }

        status = TextView(this)
        root.addView(status)

        root.addView(label("Groq API key (answers and voice)"))
        val groq = secret(if (settings.groqKey().isBlank()) "Paste Groq key" else "Saved - leave blank to keep")
        root.addView(groq)

        root.addView(label("Deepgram API key (listening)"))
        val deepgram = secret(if (settings.deepgramKey().isBlank()) "Paste Deepgram key" else "Saved - leave blank to keep")
        root.addView(deepgram)

        root.addView(label("Groq model"))
        val model = EditText(this).apply { setText(settings.groqModel()) }
        root.addView(model)

        root.addView(label("Voice"))
        val voice = Spinner(this)
        voice.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, SettingsManager.VOICES)
        voice.setSelection(SettingsManager.VOICES.indexOf(settings.ttsVoice()).coerceAtLeast(0))
        voice.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                settings.put("tts_voice", SettingsManager.VOICES[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        root.addView(voice)

        root.addView(button("Save keys") {
            if (groq.text.isNotBlank()) settings.put("groq_key", groq.text.toString().trim())
            if (deepgram.text.isNotBlank()) settings.put("deepgram_key", deepgram.text.toString().trim())
            if (model.text.isNotBlank()) settings.put("groq_model", model.text.toString().trim())
            groq.setText(""); deepgram.setText("")
            Toast.makeText(this, "Saved (keys are lost if you reinstall)", Toast.LENGTH_SHORT).show()
            refreshStatus()
        })

        root.addView(button("Test voice") {
            scope.launch {
                try {
                    val wav = GroqTts(http, settings).synthesize("Hello, I am Jarvis. Your voice is working.")
                    AudioPlayer(this@MainActivity).play(wav)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Voice test failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })

        root.addView(label("Setup"))
        root.addView(button("1. Allow microphone") {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        })
        root.addView(button("2. Set Jarvis as default assistant") {
            startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        })
        root.addView(button("3. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(TextView(this).apply {
            text = "On Android 13+, a sideloaded app needs \"Allow restricted settings\" " +
                "(App info > three dots) before the accessibility toggle works."
            setPadding(0, pad, 0, 0)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun refreshStatus() {
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val assistantSetting = Settings.Secure.getString(contentResolver, "assistant") ?: ""
        val isDefault = assistantSetting.contains(packageName) ||
            getSystemService(RoleManager::class.java)?.isRoleHeld(RoleManager.ROLE_ASSISTANT) == true
        val a11y = JarvisAccessibilityService.instance != null
        fun mark(ok: Boolean) = if (ok) "OK" else "not set"
        status.text = "Keys: ${mark(settings.groqKey().isNotBlank() && settings.deepgramKey().isNotBlank())}\n" +
            "Microphone: ${mark(mic)}\nDefault assistant: ${mark(isDefault)}\nAccessibility: ${mark(a11y)}"
    }
}
